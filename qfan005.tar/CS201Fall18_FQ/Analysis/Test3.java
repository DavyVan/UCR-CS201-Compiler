public class Test3 {

	public static void main(String[] args) {		
		func1(100);	
		func2(10);	
	}
	
	public static void func1 (int x) {
		while (x > 0) {
		    x--;
		}
	}
	public static void func2 (int x) {
		while (x < 100) {
		    x++;
		}
	}
	
}
